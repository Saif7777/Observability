# ALB Controller Installation

Follow the steps mentioned [here]("https://github.com/iam-veeramalla/aws-devops-zero-to-hero/blob/main/day-22/alb-controller-add-on.md")